<?php
	$db_host = 'localhost:3306';
	$db_user = 'root';
	$db_pass = '';
	$conn = mysql_connect($db_host,$db_user,$db_pass);
	mysql_select_db('yurshot');
?>